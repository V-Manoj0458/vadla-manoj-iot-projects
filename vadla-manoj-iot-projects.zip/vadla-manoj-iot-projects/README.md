# 🌐 IoT Projects Portfolio — Vadla Manoj Kumar

> Electronics & Communication Engineering Student | IoT Enthusiast | Embedded Systems Developer

[![Arduino](https://img.shields.io/badge/Platform-Arduino-00979D?style=flat&logo=arduino&logoColor=white)](https://www.arduino.cc/)
[![ESP8266](https://img.shields.io/badge/MCU-ESP8266-E7352C?style=flat)](https://www.espressif.com/)
[![IoT](https://img.shields.io/badge/Domain-IoT-0078D7?style=flat)](https://en.wikipedia.org/wiki/Internet_of_things)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 👨‍💻 About

Hi, I'm **Vadla Manoj Kumar**, a 2nd-year Computer Science Engineering student at **KG Reddy Institute of Engineering and Technology**, Hyderabad. I have a strong passion for **IoT**, **Embedded Systems**, and **Smart Technologies**.

This repository contains three of my hands-on IoT projects built using **Arduino**, **ESP8266**, and various sensors.

---

## 📁 Projects Overview

| # | Project | MCU/Board | Key Sensors | Description |
|---|---------|-----------|-------------|-------------|
| 1 | [Smart Energy Meter](#1-smart-energy-meter) | ESP8266 | PZEM-004T / ACS712 | Real-time power monitoring with mobile dashboard |
| 2 | [Smart Irrigation System](#2-smart-irrigation-system) | Arduino Uno | Soil Moisture, DHT11 | Automated irrigation using sensor feedback |
| 3 | [Health Monitoring System](#3-health-monitoring-system) | Arduino Uno | MAX30100, LM35/DS18B20 | Real-time heart rate & temperature tracking |

---

## 1. 🔌 Smart Energy Meter

**Folder:** `smart-energy-meter/`

An IoT-based smart energy meter that monitors real-time power consumption and displays data on a mobile dashboard via the ESP8266 Wi-Fi module.

### Features
- Real-time voltage, current, and power monitoring
- Data pushed to IoT cloud dashboard (Blynk / ThingSpeak)
- Mobile-accessible live readings
- Serial monitor output for debugging

### Hardware Required
- ESP8266 NodeMCU
- PZEM-004T or ACS712 Current Sensor
- Breadboard & Jumper Wires
- USB Cable

### Quick Start
```bash
cd smart-energy-meter
# Open smart_energy_meter.ino in Arduino IDE
# Install required libraries (see libraries.txt)
# Configure Wi-Fi credentials in config.h
# Upload to ESP8266
```

---

## 2. 💧 Smart Irrigation System

**Folder:** `smart-irrigation-system/`

An automated irrigation system that uses soil moisture sensors to determine when to water plants, reducing water waste through IoT intelligence.

### Features
- Automatic pump control based on soil moisture threshold
- DHT11 for ambient temperature & humidity monitoring
- LCD display for real-time status
- Manual override via serial command

### Hardware Required
- Arduino Uno
- Soil Moisture Sensor
- DHT11 Temperature & Humidity Sensor
- 5V Relay Module
- Mini Water Pump
- 16x2 LCD Display (optional)

### Quick Start
```bash
cd smart-irrigation-system
# Open smart_irrigation.ino in Arduino IDE
# Set moisture threshold in config section
# Upload and monitor via Serial at 9600 baud
```

---

## 3. ❤️ Health Monitoring System

**Folder:** `health-monitoring-system/`

An IoT-based health monitoring system that tracks heart rate (BPM) and body temperature in real time, useful for remote patient monitoring.

### Features
- Heart rate measurement using MAX30100 pulse oximeter
- Body temperature via LM35 / DS18B20 sensor
- OLED display for live readings
- Serial output for data logging

### Hardware Required
- Arduino Uno
- MAX30100 Pulse Oximeter Sensor
- LM35 or DS18B20 Temperature Sensor
- 0.96" OLED Display (SSD1306)
- Breadboard & Jumper Wires

### Quick Start
```bash
cd health-monitoring-system
# Open health_monitor.ino in Arduino IDE
# Install MAX30100 and Adafruit SSD1306 libraries
# Upload and open Serial Monitor at 115200 baud
```

---

## 🛠️ Tech Stack

| Category | Tools / Technologies |
|----------|---------------------|
| **Hardware** | Arduino Uno, ESP8266 NodeMCU |
| **IDE** | Arduino IDE |
| **Languages** | C / C++ (Arduino) |
| **Sensors** | ACS712, Soil Moisture, DHT11, MAX30100, LM35 |
| **Protocols** | I2C, UART, Wi-Fi (HTTP/MQTT) |
| **Platforms** | Blynk IoT, ThingSpeak |

---

## 📂 Repository Structure

```
vadla-manoj-iot-projects/
│
├── README.md
├── LICENSE
│
├── smart-energy-meter/
│   ├── smart_energy_meter.ino
│   ├── config.h
│   ├── libraries.txt
│   └── README.md
│
├── smart-irrigation-system/
│   ├── smart_irrigation.ino
│   ├── libraries.txt
│   └── README.md
│
└── health-monitoring-system/
    ├── health_monitor.ino
    ├── libraries.txt
    └── README.md
```

---

## 📬 Contact

| Platform | Details |
|----------|---------|
| 📧 Email | vadlamanojkumar45@gmail.com |
| 📞 Phone | 7337018581 |
| 📍 Location | Hyderabad, India |

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).

---

<p align="center">Made with ❤️ by Vadla Manoj Kumar</p>
