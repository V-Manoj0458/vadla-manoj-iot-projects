/*
 * ============================================================
 *   HEALTH MONITORING SYSTEM
 *   Author  : Vadla Manoj Kumar
 *   Board   : Arduino Uno
 *   Sensors : MAX30100 Pulse Oximeter, LM35 Temperature Sensor
 *   Display : 0.96" OLED SSD1306
 *   Purpose : Real-time heart rate & temperature monitoring
 * ============================================================
 */

#include <Wire.h>
#include <MAX30100_PulseOximeter.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ─── Pin Definitions ──────────────────────────────────────
#define LM35_PIN        A0      // LM35 analog output
#define OLED_RESET      -1      // Not used with I2C OLED

// ─── OLED Config ──────────────────────────────────────────
#define SCREEN_WIDTH    128
#define SCREEN_HEIGHT   64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ─── MAX30100 Pulse Oximeter ───────────────────────────────
PulseOximeter pox;

// ─── Timing ───────────────────────────────────────────────
#define REPORTING_PERIOD_MS  1000
uint32_t tsLastReport = 0;

// ─── Callback: Beat Detected ──────────────────────────────
void onBeatDetected() {
  Serial.println("[MAX30100] ♥ Beat detected!");
}

// ─── Setup ────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(100);

  Serial.println("=================================");
  Serial.println("  Health Monitoring System v1.0");
  Serial.println("  by Vadla Manoj Kumar");
  Serial.println("=================================\n");

  // Initialize OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("[OLED] Initialization failed!");
    while (true);
  }
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(10, 20);
  display.println("Health Monitor v1.0");
  display.setCursor(20, 40);
  display.println("Initializing...");
  display.display();
  delay(2000);

  // Initialize MAX30100
  Serial.print("[MAX30100] Initializing...");
  if (!pox.begin()) {
    Serial.println(" FAILED! Check wiring.");
    while (true);
  }
  Serial.println(" OK");

  pox.setIRLedCurrent(MAX30100_LED_CURR_7_6MA);
  pox.setOnBeatDetectedCallback(onBeatDetected);
}

// ─── Main Loop ────────────────────────────────────────────
void loop() {
  // Must call update() frequently for MAX30100 to work
  pox.update();

  if (millis() - tsLastReport > REPORTING_PERIOD_MS) {

    // Read heart rate and SpO2
    float heartRate = pox.getHeartRate();
    uint8_t spO2    = pox.getSpO2();

    // Read temperature from LM35
    int   rawTemp   = analogRead(LM35_PIN);
    float voltage   = rawTemp * (5.0 / 1023.0);  // Convert to voltage
    float tempC     = voltage * 100.0;            // LM35: 10mV per °C

    // Classify heart rate
    String hrStatus = classifyHeartRate(heartRate);

    // ── Serial Output ───────────────────────────────────
    Serial.println("────────────────────────────────");
    Serial.printf("  Heart Rate  : %.1f BPM  [%s]\n", heartRate, hrStatus.c_str());
    Serial.printf("  SpO2        : %d %%\n", spO2);
    Serial.printf("  Temperature : %.1f °C\n", tempC);
    Serial.println("────────────────────────────────");

    // ── OLED Display ────────────────────────────────────
    display.clearDisplay();

    // Title
    display.setTextSize(1);
    display.setCursor(25, 0);
    display.println("HEALTH MONITOR");
    display.drawLine(0, 10, 128, 10, SSD1306_WHITE);

    // Heart Rate
    display.setCursor(0, 14);
    display.print("HR: ");
    display.setTextSize(2);
    display.setCursor(28, 12);
    display.print((int)heartRate);
    display.setTextSize(1);
    display.print(" BPM");

    // SpO2
    display.setCursor(0, 34);
    display.print("SpO2: ");
    display.print(spO2);
    display.print("%");

    // Temperature
    display.setCursor(0, 46);
    display.print("Temp: ");
    display.print(tempC, 1);
    display.print(" C");

    // Status
    display.setCursor(0, 56);
    display.print("Status: ");
    display.print(hrStatus);

    display.display();

    tsLastReport = millis();
  }
}

// ─── Heart Rate Classification ────────────────────────────
String classifyHeartRate(float bpm) {
  if (bpm == 0)        return "No signal";
  if (bpm < 60)        return "Low";
  if (bpm <= 100)      return "Normal";
  if (bpm <= 120)      return "Elevated";
  return "High";
}
