# ❤️ Health Monitoring System

An IoT-based health monitoring system to track **heart rate** and **body temperature** in real time using Arduino.

## 🧰 Hardware

| Component | Qty |
|-----------|-----|
| Arduino Uno | 1 |
| MAX30100 Pulse Oximeter Sensor | 1 |
| LM35 Temperature Sensor | 1 |
| 0.96" OLED Display (SSD1306) | 1 |
| Breadboard + Jumper Wires | As needed |

## 🔌 Wiring

```
MAX30100 SDA  →  A4 (I2C SDA)
MAX30100 SCL  →  A5 (I2C SCL)
MAX30100 VIN  →  3.3V
MAX30100 GND  →  GND

OLED SDA      →  A4
OLED SCL      →  A5
OLED VCC      →  3.3V
OLED GND      →  GND

LM35 OUT      →  A0
LM35 VCC      →  5V
LM35 GND      →  GND
```

> **Note:** MAX30100 and OLED share I2C bus (address 0x57 and 0x3C respectively).

## ⚙️ Setup

1. Open `health_monitor.ino` in Arduino IDE
2. Install libraries listed in `libraries.txt`
3. Upload to Arduino Uno
4. Open Serial Monitor at **115200 baud**

## 📊 Output

| Parameter | Range | Status |
|-----------|-------|--------|
| Heart Rate | < 60 BPM | Low |
| Heart Rate | 60–100 BPM | Normal |
| Heart Rate | 101–120 BPM | Elevated |
| Heart Rate | > 120 BPM | High |
