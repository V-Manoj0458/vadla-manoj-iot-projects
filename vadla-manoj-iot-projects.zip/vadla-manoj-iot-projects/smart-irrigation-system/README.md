# 💧 Smart Irrigation System

Automated irrigation using soil moisture sensors and IoT to optimize water usage.

## 🧰 Hardware

| Component | Qty |
|-----------|-----|
| Arduino Uno | 1 |
| Soil Moisture Sensor | 1 |
| DHT11 Temp & Humidity Sensor | 1 |
| 5V Relay Module | 1 |
| Mini Submersible Water Pump | 1 |
| 16×2 LCD Display | 1 (optional) |
| Breadboard + Wires | As needed |

## 🔌 Wiring

```
Soil Sensor OUT  →  A0
DHT11 DATA       →  D7
Relay IN         →  D8
LCD RS           →  D12
LCD EN           →  D11
LCD D4–D7        →  D5, D4, D3, D2
```

## ⚙️ Setup

1. Open `smart_irrigation.ino` in Arduino IDE
2. Adjust `MOISTURE_DRY_THRESHOLD` and `MOISTURE_WET_THRESHOLD` to suit your soil type
3. Upload to Arduino Uno
4. Open Serial Monitor at **9600 baud**

## 📟 Serial Commands

| Key | Action |
|-----|--------|
| `1` | Manual pump ON |
| `0` | Manual pump OFF |
| `s` | Print status |
