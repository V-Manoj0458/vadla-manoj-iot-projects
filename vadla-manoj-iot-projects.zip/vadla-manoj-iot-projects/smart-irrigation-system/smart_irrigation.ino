/*
 * ============================================================
 *   SMART IRRIGATION SYSTEM
 *   Author  : Vadla Manoj Kumar
 *   Board   : Arduino Uno
 *   Sensors : Soil Moisture Sensor, DHT11
 *   Purpose : Automated plant watering based on soil moisture
 * ============================================================
 */

#include <DHT.h>
#include <LiquidCrystal.h>

// ─── Pin Definitions ──────────────────────────────────────
#define MOISTURE_PIN    A0    // Soil moisture sensor analog pin
#define DHT_PIN         7     // DHT11 data pin
#define RELAY_PIN       8     // Relay module (controls water pump)
#define DHT_TYPE        DHT11

// ─── LCD Pins: RS, EN, D4, D5, D6, D7 ────────────────────
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

// ─── DHT Sensor ───────────────────────────────────────────
DHT dht(DHT_PIN, DHT_TYPE);

// ─── Thresholds ───────────────────────────────────────────
#define MOISTURE_DRY_THRESHOLD   400   // Below this → soil is DRY  → pump ON
#define MOISTURE_WET_THRESHOLD   700   // Above this → soil is WET  → pump OFF

// ─── State ────────────────────────────────────────────────
bool pumpRunning = false;

// ─── Setup ────────────────────────────────────────────────
void setup() {
  Serial.begin(9600);

  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH);   // Relay is active LOW — pump OFF initially

  dht.begin();

  lcd.begin(16, 2);
  lcd.print("Smart Irrigation");
  lcd.setCursor(0, 1);
  lcd.print("  Initializing..");
  delay(2000);
  lcd.clear();

  Serial.println("=================================");
  Serial.println("  Smart Irrigation System v1.0");
  Serial.println("  by Vadla Manoj Kumar");
  Serial.println("=================================\n");
}

// ─── Main Loop ────────────────────────────────────────────
void loop() {
  // Read sensors
  int   moistureRaw = analogRead(MOISTURE_PIN);
  float temperature = dht.readTemperature();
  float humidity    = dht.readHumidity();

  // Map moisture to percentage (0–100%)
  // Raw ~1023 = dry air, ~0 = submerged
  int moisturePct = map(moistureRaw, 1023, 0, 0, 100);
  moisturePct = constrain(moisturePct, 0, 100);

  // Determine soil status
  String soilStatus;
  if (moistureRaw < MOISTURE_DRY_THRESHOLD) {
    soilStatus = "DRY";
  } else if (moistureRaw > MOISTURE_WET_THRESHOLD) {
    soilStatus = "WET";
  } else {
    soilStatus = "OK ";
  }

  // ── Pump Control Logic ────────────────────────────────
  if (moistureRaw < MOISTURE_DRY_THRESHOLD && !pumpRunning) {
    pumpON();
  } else if (moistureRaw > MOISTURE_WET_THRESHOLD && pumpRunning) {
    pumpOFF();
  }

  // ── Serial Output ─────────────────────────────────────
  Serial.println("─────────────────────────────────");
  Serial.printf("  Moisture Raw : %d\n",   moistureRaw);
  Serial.printf("  Moisture     : %d %%\n", moisturePct);
  Serial.printf("  Soil Status  : %s\n",   soilStatus.c_str());
  Serial.printf("  Temperature  : %.1f C\n", temperature);
  Serial.printf("  Humidity     : %.1f %%\n", humidity);
  Serial.printf("  Pump         : %s\n",   pumpRunning ? "ON" : "OFF");
  Serial.println("─────────────────────────────────");

  // ── LCD Update ────────────────────────────────────────
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Moist:");
  lcd.print(moisturePct);
  lcd.print("% ");
  lcd.print(soilStatus);

  lcd.setCursor(0, 1);
  lcd.print("T:");
  lcd.print((int)temperature);
  lcd.print("C ");
  lcd.print("Pump:");
  lcd.print(pumpRunning ? "ON " : "OFF");

  // ── Handle Serial Commands ────────────────────────────
  handleSerialInput();

  delay(2000);
}

// ─── Pump Control ─────────────────────────────────────────
void pumpON() {
  digitalWrite(RELAY_PIN, LOW);    // Active LOW relay
  pumpRunning = true;
  Serial.println("[PUMP] Turned ON — Soil is dry.");
}

void pumpOFF() {
  digitalWrite(RELAY_PIN, HIGH);
  pumpRunning = false;
  Serial.println("[PUMP] Turned OFF — Soil moisture sufficient.");
}

// ─── Manual Override via Serial ───────────────────────────
void handleSerialInput() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    if (cmd == '1') {
      Serial.println("[CMD] Manual pump ON.");
      pumpON();
    } else if (cmd == '0') {
      Serial.println("[CMD] Manual pump OFF.");
      pumpOFF();
    } else if (cmd == 's') {
      Serial.println("[CMD] Current status printed above.");
    }
  }
}
