# 🔌 Smart Energy Meter

An IoT-based smart energy meter using **ESP8266** for real-time power monitoring and mobile dashboard visualization.

## 🧰 Hardware

| Component | Qty |
|-----------|-----|
| ESP8266 NodeMCU | 1 |
| ACS712 Current Sensor (5A) | 1 |
| Breadboard | 1 |
| Jumper Wires | As needed |

## 🔌 Wiring

```
ACS712 OUT  →  A0 (ESP8266)
ACS712 VCC  →  3.3V
ACS712 GND  →  GND
```

## 📦 Libraries Required

See `libraries.txt` — install via Arduino IDE Library Manager.

## ⚙️ Setup

1. Open `smart_energy_meter.ino` in Arduino IDE
2. Edit `config.h` with your Wi-Fi SSID, password, and ThingSpeak API key
3. Select board: **NodeMCU 1.0 (ESP-12E Module)**
4. Upload and open Serial Monitor at **115200 baud**

## 📊 Cloud Dashboard

Data is pushed to **ThingSpeak** with three fields:
- Field 1: Voltage (V)
- Field 2: Current (A)
- Field 3: Power (W)
