/*
 * ============================================================
 *   SMART ENERGY METER
 *   Author  : Vadla Manoj Kumar
 *   Board   : ESP8266 NodeMCU
 *   Sensor  : ACS712 Current Sensor
 *   Purpose : Real-time power monitoring with cloud dashboard
 * ============================================================
 */

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include "config.h"

// ─── Pin Definitions ──────────────────────────────────────
#define ACS712_PIN  A0      // Analog input for current sensor
#define VOLTAGE_REF 230.0   // AC mains voltage (RMS), adjust per region

// ─── Calibration Constants ────────────────────────────────
#define ACS712_SENSITIVITY 0.185  // 185 mV/A for ACS712-05B
#define ADC_REF_VOLTAGE    3.3    // ESP8266 ADC reference
#define ADC_RESOLUTION     1024.0

// ─── Timing ───────────────────────────────────────────────
#define SAMPLE_INTERVAL_MS  2000   // Send data every 2 seconds
#define SAMPLES_PER_READING 500    // Samples for RMS calculation

unsigned long lastSendTime = 0;

// ─── Setup ────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(100);

  Serial.println("\n=============================");
  Serial.println("  Smart Energy Meter v1.0");
  Serial.println("  by Vadla Manoj Kumar");
  Serial.println("=============================\n");

  connectWiFi();
}

// ─── Main Loop ────────────────────────────────────────────
void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WiFi] Connection lost. Reconnecting...");
    connectWiFi();
  }

  float currentRMS  = measureCurrentRMS();
  float voltage     = VOLTAGE_REF;
  float power       = voltage * currentRMS;         // Watts
  float energyKWh   = (power / 1000.0) * (SAMPLE_INTERVAL_MS / 3600000.0);

  // Print to Serial Monitor
  Serial.println("─────────────────────────────");
  Serial.printf("  Voltage     : %.1f V\n",    voltage);
  Serial.printf("  Current     : %.3f A\n",    currentRMS);
  Serial.printf("  Power       : %.2f W\n",    power);
  Serial.printf("  Energy (δ)  : %.6f kWh\n",  energyKWh);
  Serial.println("─────────────────────────────");

  // Send to cloud every SAMPLE_INTERVAL_MS
  if (millis() - lastSendTime >= SAMPLE_INTERVAL_MS) {
    sendToCloud(voltage, currentRMS, power);
    lastSendTime = millis();
  }

  delay(SAMPLE_INTERVAL_MS);
}

// ─── Measure RMS Current ──────────────────────────────────
float measureCurrentRMS() {
  long   sumSquares = 0;
  int    rawValue   = 0;
  int    offset     = 512;  // Midpoint of ADC range

  for (int i = 0; i < SAMPLES_PER_READING; i++) {
    rawValue   = analogRead(ACS712_PIN);
    int sample = rawValue - offset;
    sumSquares += (long)sample * sample;
    delayMicroseconds(100);
  }

  float rmsRaw     = sqrt((float)sumSquares / SAMPLES_PER_READING);
  float voltage_rms = (rmsRaw / ADC_RESOLUTION) * ADC_REF_VOLTAGE;
  float currentRMS  = voltage_rms / ACS712_SENSITIVITY;

  return abs(currentRMS);
}

// ─── Connect to Wi-Fi ─────────────────────────────────────
void connectWiFi() {
  Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[WiFi] Connected!");
    Serial.printf("[WiFi] IP Address: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n[WiFi] Failed to connect. Running in offline mode.");
  }
}

// ─── Send Data to Cloud (ThingSpeak) ──────────────────────
void sendToCloud(float voltage, float current, float power) {
  if (WiFi.status() != WL_CONNECTED) return;

  WiFiClient client;
  HTTPClient http;

  String url = String(THINGSPEAK_URL) +
               "?api_key=" + String(THINGSPEAK_API_KEY) +
               "&field1=" + String(voltage, 2) +
               "&field2=" + String(current, 3) +
               "&field3=" + String(power, 2);

  http.begin(client, url);
  int httpCode = http.GET();

  if (httpCode == HTTP_CODE_OK) {
    Serial.println("[Cloud] Data sent successfully.");
  } else {
    Serial.printf("[Cloud] Error sending data. HTTP code: %d\n", httpCode);
  }

  http.end();
}
