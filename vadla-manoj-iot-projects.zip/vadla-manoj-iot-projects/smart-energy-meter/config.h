/*
 * config.h — Smart Energy Meter Configuration
 * Author: Vadla Manoj Kumar
 *
 * ⚠️  DO NOT commit real credentials to GitHub.
 *     Add config.h to .gitignore or use environment variables.
 */

#ifndef CONFIG_H
#define CONFIG_H

// ─── Wi-Fi Credentials ────────────────────────────────────
#define WIFI_SSID       "YOUR_WIFI_SSID"
#define WIFI_PASSWORD   "YOUR_WIFI_PASSWORD"

// ─── ThingSpeak Cloud ─────────────────────────────────────
#define THINGSPEAK_URL      "http://api.thingspeak.com/update"
#define THINGSPEAK_API_KEY  "YOUR_THINGSPEAK_WRITE_API_KEY"

// ─── Optional: Blynk ──────────────────────────────────────
// #define BLYNK_AUTH_TOKEN  "YOUR_BLYNK_TOKEN"

#endif // CONFIG_H
